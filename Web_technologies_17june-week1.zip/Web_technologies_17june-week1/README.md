# Web_technologies_17june

![Project 1:Verse](https://github.com/Amytrainer/Web_technologies_17june/blob/week1/Output%20Preview.jpeg)
